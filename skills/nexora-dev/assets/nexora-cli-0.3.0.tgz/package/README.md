# Nexora 图片 CLI

Node.js 22+ 的 TypeScript CLI，仅提供自由创作图片生成。复用云端 OAuth，直接调用图片 HTTP API。安装包内为编译后的 JavaScript，npm 自动生成 CMD 的 nexora.cmd，无需手写启动脚本。

## 本地构建和安装

在 cli 目录执行（CMD）：

```cmd
pack.cmd
npm install -g .\release\nexora\assets\nexora-cli-0.3.0.tgz
nexora --version
```

`pack.cmd` 自动切换到脚本所在目录，依次安装锁定依赖、检查类型、构建并运行测试、打包 CLI、打包 Skill、验证发布物；任一步失败即停止并返回非零退出码。找不到 pnpm 时，通过 npm exec 使用 package.json 中锁定的 pnpm（可能需要网络，不全局安装）。需要系统 tar.exe（Windows 10/11 通常自带）。脚本不会自动全局安装、登录或调用真实生图服务。

当前版本产物：

- `cli/release/nexora/assets/nexora-cli-0.3.0.tgz`：CLI 安装包，统一保存在 Skill 的 assets 目录。
- `cli/release/nexora/`：可直接复制的完整 Skill 目录。
- `cli/release/nexora-0.3.0.tar.gz`：Skill 分发包，解压后得到 nexora 目录。

Skill 发布包内附带 CLI tgz，`release.json` 记录版本、安装包路径、Node 要求和 SHA-256。Agent 使用 Skill 时会先检查并复用现有 Node22+/npm；缺失时自动下载官方 LTS 到用户目录，随后自动安装包内 CLI，无需用户另行确认安装。Skill 默认 OAuth 服务为 `http://127.0.0.1:48080`，直接带 `--allow-http` 启动登录，用户只需完成网页上的账号登录和授权；用户明确指定其他环境时才覆盖地址。

Skill 源文件在 [skills/nexora](../skills/nexora/SKILL.md)，只维护指令与参考资料，不内置另一套业务脚本。将完整发布目录放入目标 Agent 支持的 skills 路径，并按该 Agent 的方式加载；不要只复制 SKILL.md。CLI 命令和 Skill 均叫 `nexora`，图片命令继续使用 `nexora image ...`。上述自动准备由运行 Skill 的 Agent 执行，`pack.cmd` 本身仍只负责构建与验证。

发布验证会解压分发包，在系统临时目录以独立 npm prefix 安装 CLI，检查版本和命令，随后清理临时目录。不会修改用户全局 CLI 或现有凭据。npm 安装依赖可能访问 registry，这不是离线发行包。若依赖已缓存，可设置 `NEXORA_RELEASE_TEST_OFFLINE=1` 让发布验证离线安装。

当前尚未发布到在线仓库。`pack.cmd` 验证后在 `cli/release/` 生成完整 Skill 包和外层 `release.json`（包含归档 SHA-256），不再向后端复制文件。后端独立模块 `auana-module-agent-plugin` 从配置的发布目录直接读取，维护安装说明并提供下载；前端 `/plugin` 仅展示入口。包内含配套 CLI tgz，不含源码、测试或凭据。页面与本地配置见 [Plugin 安装入口](../doc/plugin-install.md)，OAuth 前提见 [接入文档](../doc/agent-oauth-mcp.md)。

## 登录及生成

将地址替换为已配置 issuer 的实际 origin，不能使用另一个主机名代替：

```cmd
nexora login --server http://127.0.0.1:48080 --allow-http
nexora auth status
nexora image options
nexora image generate --prompt "极简风格的香水产品海报"
nexora image generate --prompt "保留商品，背景改为海边日落" --reference "D:\商品.png"
```

login 自动发现、动态登记、打开浏览器并监听随机数值 loopback 端口，用户在网页确认。若浏览器未自动打开，复制 stderr 中的授权地址。默认 HTTPS；HTTP 仅在明确 --allow-http 时接受。CLI 与 MCP 独立登记、持有独立凭据，不读取 Agent Token。

凭据默认保存在用户目录 .nexora/credentials.json，POSIX目录0700/文件0600，Windows使用当前用户ACL；原子写和跨进程刷新锁。NEXORA_CONFIG_DIR 可指定独立配置目录。刷新响应不确定时需重新 login，不会重放旧 Refresh Token。

```cmd
nexora logout
```

先尝试撤销云端再清除本地；离线会说明撤销未确认，可到网页连接管理撤销。

## 参数及默认值

| 参数 | 默认/限制 |
| --- | --- |
| --prompt | 新请求必填，最多4000字 |
| --reference | 可重复，最多4张PNG/JPEG/WebP，每张10MiB |
| --reference-asset | 可重复，直接复用已有assetId；与本地图合计最多4张，顺序为本地图在前、资产在后 |
| --model | 自由创作功能点默认模型 |
| --count | 1，范围1～4 |
| --ratio / --image-size / --quality | 不传则用服务端模型默认；是否支持和值域查看 image options |
| --param key=value | 可重复，只允许当前模型公开schema字段，最多32项；按schema解析数字/布尔 |
| --brand | 本人已发布品牌风格编号，可省略 |
| --conversation | 本人会话，可省略新建 |
| --output | ./nexora-results/runId |
| --timeout | 1800秒，最大86400秒 |
| --no-wait | 默认等待并下载；指定后仅返回已受理身份 |
| --resume | 自动请求记录路径；仅可与timeout/no-wait/json同用 |
| --json | stdout单JSON envelope，进度写stderr |

同一参数不能通过别名和 --param 重复覆盖。模型没有唯一别名对应字段时用 --param 实际字段名=值。默认参数与价格由服务端功能点配置决定，不在CLI写死。

### 复用已生成的参考图

```cmd
nexora image generate --prompt "保留猫咪，背景改成花园" --reference-asset ASSET_ID --no-wait --json
```

ASSET_ID 来自之前下载结果的 `files[].assetId`，不使用 fileId 或下载URL。也可以直接把原下载目录中的图片传给 `--reference`：CLI匹配同目录manifest、大小和SHA-256，校验账号/服务及原Run实时结果后复用，不创建上传会话。文件已修改或没有匹配清单则正常上传；身份不符或原资产失效会报错，不静默重传。显式引用与自动识别使用后端已有归属和状态校验，不改后端业务。

新任务使用版本2恢复记录，将参考图来源及顺序纳入摘要；自动复用后即使本地文件移走，也可按原记录继续。兼容版本1记录。此能力避免重复上传已识别生成图，不提供任意本地图片全局去重，也不删除OSS已有副本。

## 状态、恢复与下载

```cmd
nexora image generate --prompt "极简海报" --no-wait --json
nexora image status RUN_ID --json
nexora image wait RUN_ID --timeout 1800 --json
nexora image download RUN_ID --output ".\results" --json
nexora image generate --resume ".\.nexora-requests\请求编号.json"
```

CLI 在上传和提交前自动保存请求记录，并在上传会话/资产/受理推进后更新；stderr、成功结果以及失败时的 `error.recovery` 提供记录路径，不要求用户准备JSON。恢复检查主体、服务器、资源、输入摘要和未受理请求的本地文件内容，沿用原幂等键。提交响应丢失时必须使用原记录，不能重新执行相同prompt创建新键。上传会话已过期时会报错，需确认原请求未受理后重新开始。

中断或超时不取消云端。download可在部分成功时下载已有文件，manifest.json记录稳定资产/文件ID及实际SHA-256，不保存签名URL。已有文件通过清单与大小/摘要校验后跳过，否则拒绝覆盖；随机.part排他写入、校验后落盘，拒绝符号链接目录和不可信重定向。签名过期自动重查一次；向存储请求不发送API Token。

输出形如 {"ok":true,"code":0,"data":{...}}。失败时为 `error.message`，有恢复上下文时额外包含 `error.recovery`：`action` 为 resume/status/wait/download，附适用的 record/runId/output。需要先处理参数或授权错误，恢复动作不等于无限自动重试。API密钥、Token和签名URL不进入错误文本/请求记录/下载清单。

```json
{"ok":false,"code":6,"error":{"message":"网络请求失败或超时","recovery":{"action":"resume","record":"D:\\work\\.nexora-requests\\原编号.json"}}}
```

| 退出码 | 含义 |
| --- | --- |
| 0 | 查询成功、全部交付或明确已受理 |
| 2 | 参数或契约格式错误 |
| 3 | 未登录、权限不足或认证失败 |
| 4 | 云端业务失败/取消 |
| 5 | 部分成功 |
| 6 | 网络、等待超时或提交结果不确定 |
| 7 | 下载失败（优先于云端部分失败） |
| 130 | 中断 |

测试只调用本地替身；真实图片生成会消耗云端额度，需要用户主动执行。
